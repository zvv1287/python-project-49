# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_games:brain_calc',
                     'brain-even = brain_games.scripts.brain_games:brain_even',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gsd = brain_games.scripts.brain_games:brain_gsd',
                     'brain-prime = '
                     'brain_games.scripts.brain_games:brain_prime',
                     'brain-progression = '
                     'brain_games.scripts.brain_games:brain_progression']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/zvv1287/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zvv1287/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/aad09d4c94aae252d5c1/maintainability)](https://api.codeclimate.com/v1/badges/aad09d4c94aae252d5c1/maintainability)\n\n### Ссылка на аскинему с записью работы программы:\nшаг 5\nhttps://asciinema.org/a/9bTwocKzmMHjqTzjOytAq7kNg\nшаг 6\nhttps://asciinema.org/a/VFGGwWgpoJEbv1kTwtlMerMp2\nшаг 7\nhttps://asciinema.org/a/2D2VdLsntXjnmbcLHVsl32T2o\nшаг 8\nhttps://asciinema.org/a/FO9XCmlcdkmfsxSVEWv62T4Ji\nшаг 9\nhttps://asciinema.org/a/vlTz6LZFM4RBieXIR7v8o6sy6\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
